# lecture0

all about simple codes helping people to start making websites 
